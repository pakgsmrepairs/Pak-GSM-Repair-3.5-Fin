# Pak GSM Repair 5.5 — Android Native Bluetooth starter

یہ پیکج آپ کی فراہم کردہ `Pak_GSM_Repair_5.5_Dashboard_OptionB.zip` کے ویب ایپ مواد کو Android WebView ایپ میں رکھتا ہے، اور Android کے مقامی Bluetooth کے ساتھ ابتدائی integration شامل کرتا ہے۔

## اس ورژن میں شامل
- اصل `index.html`، `cloud-config.js`، `manifest.json`، `sw.js` اور `update.json` کو Android assets میں شامل کیا گیا ہے۔
- Bluetooth آپشن کی موجودہ dashboard/menu placement برقرار رکھی گئی ہے۔
- Android bridge paired Bluetooth devices کے نام، پتہ، قسم اور paired state پڑھتا ہے۔
- Bluetooth diagnostics سے Android Bluetooth settings کھولی جا سکتی ہیں تاکہ صارف ڈیوائس کو system settings میں pair/connect کرے۔
- GitHub Actions workflow debug APK build کر کے Artifact اپلوڈ کرتا ہے۔

## اہم حدود — براہِ کرم ضرور پڑھیں
یہ **ابتدائی integration/source package ہے، تصدیق شدہ/ٹیسٹ شدہ APK نہیں**۔ اس ماحول میں Android SDK/Gradle build چلایا نہیں گیا، لہٰذا GitHub Actions build کو کامیاب ہونا ابھی verify کرنا باقی ہے۔

Android کی public APIs ہر Bluetooth headset کی حقیقی connected state، battery level یا ANC/Transparency modes کو عمومی طور پر نہیں دیتیں۔ اس package میں paired-device list دکھائی جاتی ہے اور system Bluetooth settings کھولی جاتی ہیں۔ ANC، Transparency، Spatial Audio، equalizer وغیرہ کے اصل controls کے لیے ہر متعلقہ brand/model کا supported SDK یا vendor protocol درکار ہو سکتا ہے۔ ابھی ان موڈز کو حقیقی طور پر toggle کرنے کا دعویٰ نہیں کیا جاتا۔

## GitHub پر APK build کرنے کا طریقہ
1. ZIP extract کریں۔
2. اس ZIP کے **اندر موجود تمام files/folders** اپنے نئے یا منتخب repository کے root میں upload کریں۔ `app`, `.github`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties` root پر ہوں۔
3. GitHub → Actions → `Build Pak GSM Repair Android APK` کھولیں۔
4. `Run workflow` → branch `main` → `Run workflow` دبائیں۔
5. build مکمل ہونے پر run کھولیں اور `Artifacts` سے `Pak-GSM-Repair-5.5-Native-Bluetooth-debug-APK` ڈاؤن لوڈ کریں۔
6. پہلے اپنے ٹیسٹ فون پر انسٹال کر کے permissions، login/cloud، records، backup اور Bluetooth settings flow چیک کریں۔

## موجودہ ویب ورژن اور Android APK میں فرق
GitHub Pages والا HTTPS ورژن browser میں چلتا رہے گا اور اس میں Web Bluetooth browser chooser کھل سکتا ہے۔ Native Bluetooth bridge صرف اس Android project کے اندر دستیاب ہے؛ صرف HTML کو GitHub Pages پر upload کرنے سے Android system Bluetooth APIs دستیاب نہیں ہوں گی۔
