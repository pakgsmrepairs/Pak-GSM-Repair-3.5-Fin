package com.pakgsm.repair;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int BT_PERMISSION_REQUEST = 410;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new NativeBluetoothBridge(this), "PGRNativeBluetooth");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissionsIfNeeded();
    }
    private void requestBluetoothPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, BT_PERMISSION_REQUEST);
        } else if (Build.VERSION.SDK_INT <= 30 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, BT_PERMISSION_REQUEST);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BT_PERMISSION_REQUEST && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Bluetooth permission granted", Toast.LENGTH_SHORT).show();
        }
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    public class NativeBluetoothBridge {
        private final Context context;
        NativeBluetoothBridge(Context c) { context = c; }
        @JavascriptInterface public String getPairedDevices() {
            JSONObject result = new JSONObject();
            JSONArray devices = new JSONArray();
            try {
                if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    result.put("error", "Bluetooth permission is not granted. Allow Nearby devices permission, then try again.");
                    return result.toString();
                }
                BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
                BluetoothAdapter adapter = manager != null ? manager.getAdapter() : null;
                if (adapter == null) { result.put("error", "This phone does not provide Bluetooth."); return result.toString(); }
                if (!adapter.isEnabled()) { result.put("error", "Bluetooth is off. Turn Bluetooth on in Android settings, then try again."); return result.toString(); }
                Set<BluetoothDevice> bonded = adapter.getBondedDevices();
                for (BluetoothDevice d : bonded) {
                    JSONObject item = new JSONObject();
                    item.put("name", safeName(d));
                    item.put("address", d.getAddress() == null ? "" : d.getAddress());
                    item.put("type", typeName(d.getType()));
                    item.put("bondState", d.getBondState() == BluetoothDevice.BOND_BONDED ? "Paired" : "Not paired");
                    devices.put(item);
                }
                result.put("devices", devices);
            } catch (SecurityException e) {
                try { result.put("error", "Android blocked Bluetooth access. Grant Nearby devices permission and retry."); } catch(Exception ignored) {}
            } catch (Exception e) {
                try { result.put("error", "Could not read paired devices: " + e.getMessage()); } catch(Exception ignored) {}
            }
            return result.toString();
        }
        private String safeName(BluetoothDevice d) {
            try { String n = d.getName(); return n == null || n.trim().isEmpty() ? "Unknown Bluetooth device" : n; }
            catch (SecurityException e) { return "Bluetooth device"; }
        }
        private String typeName(int type) {
            if (type == BluetoothDevice.DEVICE_TYPE_LE) return "BLE";
            if (type == BluetoothDevice.DEVICE_TYPE_DUAL) return "Classic + BLE";
            if (type == BluetoothDevice.DEVICE_TYPE_CLASSIC) return "Classic";
            return "Unknown";
        }
        @JavascriptInterface public void openBluetoothSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "Unable to open Bluetooth settings", Toast.LENGTH_SHORT).show(); }
            });
        }
    }
}
